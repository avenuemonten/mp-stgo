import { HTML_BR, HTML_MI, HTML_MR, HTML_PLOMB, HTML_SF, HTML_SGE } from './htmlTemplates';
import type { ActTemplateConfig } from '../types';

const COMMON_FIELDS_TOP = [
  { section: 'Данные акта', key: 'act_number', label: 'Номер акта', type: 'string', required: true },
  { section: 'Данные акта', key: 'act_date', label: 'Дата акта', type: 'date', required: true },
  { section: 'Абонент', key: 'owner_name', label: 'ФИО абонента', type: 'string', required: true },
  { section: 'Абонент', key: 'owner_phone', label: 'Телефон абонента', type: 'string' },
  { section: 'Объект', key: 'object_type', label: 'Тип объекта', type: 'string' },
  { section: 'Объект', key: 'object_address', label: 'Адрес объекта', type: 'address', required: true },
] as const;

export const ACT_TEMPLATES_REGISTRY: Record<string, ActTemplateConfig> = {
  actbr: {
    type: 'actbr',
    name: 'Акт замены аккумуляторной батареи',
    htmlTemplate: HTML_BR,
    fields: [
      ...COMMON_FIELDS_TOP,
      { section: 'Снятый счетчик', key: 'removed_meter_model', label: 'Модель', type: 'string', required: true },
      { section: 'Снятый счетчик', key: 'removed_meter_number', label: 'Номер', type: 'string', required: true },
      { section: 'Снятый счетчик', key: 'removed_meter_reading', label: 'Показания', type: 'string' },
      { section: 'Снятый счетчик', key: 'removed_seal_number', label: 'Номер пломбы', type: 'string' },

      { section: 'Установленный счетчик', key: 'installed_meter_model', label: 'Модель', type: 'string', required: true },
      { section: 'Установленный счетчик', key: 'installed_meter_number', label: 'Номер', type: 'string', required: true },
      { section: 'Установленный счетчик', key: 'installed_meter_reading', label: 'Показания', type: 'string' },
      { section: 'Установленный счетчик', key: 'installed_seal_number', label: 'Номер пломбы', type: 'string' },

      { section: 'Подписи', key: 'technician_name', label: 'ФИО слесаря', type: 'string' },
      { section: 'Подписи', key: 'technician_signature', label: 'Подпись слесаря', type: 'signature' },
      { section: 'Подписи', key: 'owner_signature', label: 'Подпись абонента', type: 'signature' },
    ],
  },

  actplomb: {
    type: 'actplomb',
    name: 'Акт пломбирования прибора учета газа',
    htmlTemplate: HTML_PLOMB,
    fields: [
      ...COMMON_FIELDS_TOP,

      // 1-й прибор (совместимость со старыми ключами meter_* / seal_number / note)
      { section: 'Прибор учета (1)', key: 'meter_model', label: 'Модель (после G-)', type: 'string', required: true },
      { section: 'Прибор учета (1)', key: 'meter_number', label: 'Номер счётчика', type: 'string', required: true },
      { section: 'Прибор учета (1)', key: 'meter_reading', label: 'Текущие показания (м³)', type: 'string' },
      { section: 'Прибор учета (1)', key: 'seal_number', label: 'Номер пломбы', type: 'string' },
      { section: 'Прибор учета (1)', key: 'note', label: 'Примечания', type: 'textarea' },

      // 2-й прибор (опционально)
      { section: 'Прибор учета (2)', key: 'meter2_model', label: 'Модель (после G-)', type: 'string' },
      { section: 'Прибор учета (2)', key: 'meter2_number', label: 'Номер счётчика', type: 'string' },
      { section: 'Прибор учета (2)', key: 'meter2_reading', label: 'Текущие показания (м³)', type: 'string' },
      { section: 'Прибор учета (2)', key: 'meter2_seal_number', label: 'Номер пломбы', type: 'string' },
      { section: 'Прибор учета (2)', key: 'meter2_note', label: 'Примечания', type: 'textarea' },

      // 3-й прибор (опционально)
      { section: 'Прибор учета (3)', key: 'meter3_model', label: 'Модель (после G-)', type: 'string' },
      { section: 'Прибор учета (3)', key: 'meter3_number', label: 'Номер счётчика', type: 'string' },
      { section: 'Прибор учета (3)', key: 'meter3_reading', label: 'Текущие показания (м³)', type: 'string' },
      { section: 'Прибор учета (3)', key: 'meter3_seal_number', label: 'Номер пломбы', type: 'string' },
      { section: 'Прибор учета (3)', key: 'meter3_note', label: 'Примечания', type: 'textarea' },

      { section: 'Подписи', key: 'technician_name', label: 'ФИО сотрудника', type: 'string' },
      { section: 'Подписи', key: 'technician_signature', label: 'Подпись сотрудника', type: 'signature' },
      { section: 'Подписи', key: 'owner_signature', label: 'Подпись абонента', type: 'signature' },

      // если не заполнено — в PDF будет act_date
      { section: 'Подписи', key: 'received_date', label: 'Дата получения акта (опционально)', type: 'date' },
    ],
  },

  actmr: {
    type: 'actmr',
    name: 'Акт замены счетчика',
    htmlTemplate: HTML_MR,
    fields: [
      ...COMMON_FIELDS_TOP,
      { section: 'Причина', key: 'reason', label: 'Причина замены', type: 'textarea', required: true },
    ],
  },

  actmi: {
    type: 'actmi',
    name: 'Акт установки прибора',
    htmlTemplate: HTML_MI,
    fields: [
      ...COMMON_FIELDS_TOP,
      { section: 'Прибор учета', key: 'meter_model', label: 'Модель', type: 'string' },
      { section: 'Прибор учета', key: 'meter_number', label: 'Номер', type: 'string' },
      { section: 'Пломба', key: 'seal_place', label: 'Место установки пломбы', type: 'string' },
    ],
  },

  actsf: {
    type: 'actsf',
    name: 'Акт снятия фотопоказаний',
    htmlTemplate: HTML_SF,
    fields: [
      ...COMMON_FIELDS_TOP,
      { section: 'Показания', key: 'meter_reading', label: 'Показания', type: 'string' },
      { section: 'Фото', key: 'photo_data', label: 'Фото', type: 'image' },
    ],
  },

  actsge: {
    type: 'actsge',
    name: 'Акт обследования газового оборудования',
    htmlTemplate: HTML_SGE,
    fields: [
      ...COMMON_FIELDS_TOP,
      { section: 'Описание', key: 'note', label: 'Описание', type: 'textarea' },
    ],
  },

  work_completed: {
    type: 'work_completed',
    name: 'Акт выполненных работ',
    htmlTemplate: HTML_BR, // TODO: заменить на отдельный шаблон, когда будет готов
    fields: [...COMMON_FIELDS_TOP],
  },
};
