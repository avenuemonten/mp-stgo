import { USD_LOGO_BASE64 } from '../../../constants/logo';

type ParsedDate = { full: string; short: string; year: string };

// Умный парсер даты.
// Принимает ISO (2026-01-21) и вернет:
// full: 21.01.2026
// short: 21.01
// year: 2026
const parseDateSmart = (value?: string): ParsedDate => {
  if (!value) return { full: '___', short: '__.__', year: '____' };

  const d = new Date(value);
  if (!Number.isNaN(d.getTime())) {
    const day = d.getDate().toString().padStart(2, '0');
    const month = (d.getMonth() + 1).toString().padStart(2, '0');
    const year = d.getFullYear().toString();
    return {
      full: `${day}.${month}.${year}`,
      short: `${day}.${month}`,
      year,
    };
  }

  // Если прилетело уже отформатированное значение
  const m = value.match(/(\d{2})\.(\d{2})\.(\d{4})/);
  if (m) {
    return {
      full: `${m[1]}.${m[2]}.${m[3]}`,
      short: `${m[1]}.${m[2]}`,
      year: m[3],
    };
  }

  const y = value.match(/(\d{4})/);
  return { full: value, short: value, year: y?.[1] || '____' };
};

// Если пользователь ввел "ACT-01-0004/2026", то вернем:
// number = "ACT-01-0004", year = "2026"
const parseActNumberAndYear = (raw?: string, fallbackYear?: string) => {
  const s = (raw || '').trim();
  if (!s) return { number: 'Б/Н', year: fallbackYear || '____' };

  const parts = s.split('/').map(p => p.trim()).filter(Boolean);
  const last = parts[parts.length - 1];
  if (parts.length >= 2 && /^\d{4}$/.test(last)) {
    return {
      number: parts.slice(0, -1).join('/'),
      year: last,
    };
  }

  return { number: s, year: fallbackYear || '____' };
};

const escapeHtml = (v: any) => {
  const s = String(v ?? '');
  return s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
};

const pick = (obj: Record<string, any>, keys: string[]) => {
  for (const k of keys) {
    const v = obj?.[k];
    if (v !== undefined && v !== null && String(v).trim() !== '') return v;
  }
  return undefined;
};

const normalizeDataUrl = (val: any): string | null => {
  if (!val) return null;

  if (typeof val === 'string') {
    const s = val.trim();
    if (!s) return null;
    return s.startsWith('data:') ? s : `data:image/png;base64,${s}`;
  }

  if (typeof val === 'object' && typeof val.dataUrl === 'string' && val.dataUrl.trim()) {
    return val.dataUrl.trim();
  }

  return null;
};

const formatImg = (dataUrlLike: any, maxHeight = 55) => {
  const dataUrl = normalizeDataUrl(dataUrlLike);
  if (!dataUrl) return '';
  const safe = dataUrl.replaceAll('"', '%22'); // минимальная защита атрибута
  return `<img src="${safe}" style="max-height: ${maxHeight}px; width: auto; display: block;" />`;
};

export const fillActTemplate = (htmlTemplate: string, act: any) => {
  const common = act || {};
  const d = common.details || {};

  // Парсим даты
  const actDate = parseDateSmart(common.act_date);
  const remDate = parseDateSmart(d.removal_date);
  const instDate = parseDateSmart(d.installation_date);
  const receivedDate = parseDateSmart(d.received_date || common.act_date);

  // Парсим номер/год из act_number, чтобы не получить ".../2026/2026"
  const actNum = parseActNumberAndYear(common.act_number, actDate.year);

  const objectAddress =
    typeof d.object_address === 'object'
      ? d.object_address?.address
      : (d.object_address || '');

  // Маппинг значений для шаблонов
  const replacements: Record<string, string> = {
    // Общие
    '{{LOGO_SRC}}': USD_LOGO_BASE64 || '',
    '{{NUMBER}}': escapeHtml(actNum.number || 'Б/Н'),
    '{{YEAR}}': escapeHtml(actNum.year || actDate.year),
    '{{ACT_NUMBER}}': escapeHtml(common.act_number || 'Б/Н'),

    // Даты
    '{{ACT_DATE}}': escapeHtml(actDate.short),      // 21.01 (как в BR-шаблоне)
    '{{ACT_YEAR}}': escapeHtml(actNum.year || actDate.year),
    '{{ACT_DATE_FULL}}': escapeHtml(actDate.full), // 21.01.2026

    '{{REMOVAL_DATE}}': escapeHtml(remDate.short),
    '{{REMOVAL_YEAR}}': escapeHtml(remDate.year),
    '{{REMOVAL_DATE_FULL}}': escapeHtml(remDate.full),

    '{{INSTALLATION_DATE}}': escapeHtml(instDate.short),
    '{{INSTALLATION_YEAR}}': escapeHtml(instDate.year),
    '{{INSTALLATION_DATE_FULL}}': escapeHtml(instDate.full),

    '{{RECEIVED_DATE}}': escapeHtml(receivedDate.full),

    // Люди и адрес
    '{{TECHNICIAN_NAME}}': escapeHtml(d.technician_name || '________________'),
    '{{OWNER_NAME}}': escapeHtml(d.owner_name || '________________'),
    '{{OWNER_PHONE}}': escapeHtml(d.owner_phone || ''),
    '{{OBJECT_TYPE}}': escapeHtml(d.object_type || '_________'),
    '{{OBJECT_ADDRESS}}': escapeHtml(objectAddress || '________________'),

    // --- СНЯТИЕ ---
    '{{REMOVED_METER_MODEL}}': escapeHtml(d.removed_meter_model || '______'),
    '{{REMOVED_METER_NUMBER}}': escapeHtml(d.removed_meter_number || '______'),
    '{{REMOVED_METER_READING}}': escapeHtml(d.removed_meter_reading || '______'),
    '{{REMOVED_SEAL_NUMBER}}': escapeHtml(d.removed_seal_number || '______'),

    // --- УСТАНОВКА ---
    '{{INSTALLED_METER_MODEL}}': escapeHtml(d.installed_meter_model || d.meter_model || '______'),
    '{{INSTALLED_METER_NUMBER}}': escapeHtml(d.installed_meter_number || d.meter_number || '______'),
    '{{INSTALLED_METER_READING}}': escapeHtml(d.installed_meter_reading || '______'),
    '{{INSTALLED_SEAL_NUMBER}}': escapeHtml(d.installed_seal_number || d.seal_number || '______'),

    // --- Универсальные (старые) ---
    '{{METER_MODEL}}': escapeHtml(d.meter_model || '______'),
    '{{METER_NUMBER}}': escapeHtml(d.meter_number || '______'),
    '{{METER_READING}}': escapeHtml(d.meter_reading || '______'),
    '{{SEAL_NUMBER}}': escapeHtml(d.seal_number || '______'),
    '{{SEAL_PLACE}}': escapeHtml(d.seal_place || '______'),
    '{{NOTE}}': escapeHtml(d.note || ''),
    '{{REASON}}': escapeHtml(d.reason || '________________'),
    '{{METHOD}}': escapeHtml(d.method || '________________'),

    // --- ActPlomb (плейсхолдеры под DOCX) ---
    '{{M1_MODEL}}': escapeHtml(pick(d, ['meter1_model', 'm1_model', 'meter_model']) ?? '______'),
    '{{M1_NUMBER}}': escapeHtml(pick(d, ['meter1_number', 'm1_number', 'meter_number']) ?? '______'),
    '{{M1_READING}}': escapeHtml(pick(d, ['meter1_reading', 'm1_reading', 'meter_reading']) ?? '______'),
    '{{M1_SEAL_NUMBER}}': escapeHtml(pick(d, ['meter1_seal_number', 'm1_seal_number', 'seal_number']) ?? '______'),
    '{{M1_NOTE}}': escapeHtml(pick(d, ['meter1_note', 'm1_note', 'note']) ?? '________________'),

    '{{M2_MODEL}}': escapeHtml(pick(d, ['meter2_model', 'm2_model']) ?? '______'),
    '{{M2_NUMBER}}': escapeHtml(pick(d, ['meter2_number', 'm2_number']) ?? '______'),
    '{{M2_READING}}': escapeHtml(pick(d, ['meter2_reading', 'm2_reading']) ?? '______'),
    '{{M2_SEAL_NUMBER}}': escapeHtml(pick(d, ['meter2_seal_number', 'm2_seal_number']) ?? '______'),
    '{{M2_NOTE}}': escapeHtml(pick(d, ['meter2_note', 'm2_note']) ?? '________________'),

    '{{M3_MODEL}}': escapeHtml(pick(d, ['meter3_model', 'm3_model']) ?? '______'),
    '{{M3_NUMBER}}': escapeHtml(pick(d, ['meter3_number', 'm3_number']) ?? '______'),
    '{{M3_READING}}': escapeHtml(pick(d, ['meter3_reading', 'm3_reading']) ?? '______'),
    '{{M3_SEAL_NUMBER}}': escapeHtml(pick(d, ['meter3_seal_number', 'm3_seal_number']) ?? '______'),
    '{{M3_NOTE}}': escapeHtml(pick(d, ['meter3_note', 'm3_note']) ?? '________________'),

    // Фото (actsf)
    '{{PHOTO_DATA}}': normalizeDataUrl(d.photo_data) || '',

    // Подписи (поддерживаем и object.dataUrl, и строку dataUrl)
    '{{TECHNICIAN_SIGNATURE}}': formatImg(d.technician_signature, 55),
    '{{OWNER_SIGNATURE}}': formatImg(d.owner_signature, 55),
  };

  let result = htmlTemplate;
  for (const [key, value] of Object.entries(replacements)) {
    result = result.split(key).join(value);
  }

  return result;
};
